#!/usr/bin/env python3
r"""
flatten_patient_reports.py  -  incremental patient-JSON -> unified dataset

Each run scans a folder of patient JSON reports, processes ONLY files not seen
before (tracked in a processed-log), flattens them, and refreshes a unified
dataset in FOUR formats at once:

    patient_reports.jsonl     append-only master  (best for LLM / CDSS training)
    patient_reports.parquet   columnar, compressed (best for pandas / analysis)
    patient_reports.csv       flat wide table
    patient_reports.xlsx      Excel  (skipped only if > 16,384 columns)

Rules: 1 row per file; columns = union of every flattened field ever seen;
missing field -> blank/null; nested objects -> dot notation
("patient.demographics.age"); arrays -> comma-separated strings.

INCREMENTAL DESIGN (safe to run every month)
    * processed_log.csv lists every file already handled (name, size, mtime,
      processed_at, field count, status). On each run the script reads it,
      SKIPS those files, parses only the new ones, appends their flat records
      to the master JSONL, and logs them for next time.
    * A new month can introduce NEW fields, so the column union can grow. The
      master JSONL is append-only; parquet/csv/xlsx are rebuilt from it so
      their headers always include newly discovered fields. Only NEW files are
      ever parsed (the expensive step); rebuilding the views is fast writing.

STATE FILES live in --state-dir (default <input_dir>/_pipeline):
    processed_log.csv, _headers.json, patient_reports.{jsonl,parquet,csv,xlsx},
    patient_reports_field_summary.csv

USAGE (identical in CMD, PowerShell, Windows Terminal):
    python flatten_patient_reports.py "C:\path\to\JSON"
    python flatten_patient_reports.py "C:\path\to\JSON" --rebuild
    python flatten_patient_reports.py "C:\path\to\JSON" --formats parquet,jsonl
"""
from __future__ import annotations

import argparse
import csv
import json
import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Set, Tuple

import pandas as pd
from openpyxl import Workbook

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s  %(levelname)-7s  %(message)s",
                    datefmt="%H:%M:%S")
log = logging.getLogger("flatten")

EXCEL_MAX_COLS = 16_384
EXCEL_MAX_ROWS = 1_048_576
ALL_FORMATS = ["jsonl", "parquet", "csv", "xlsx"]
MASTER_JSONL = "patient_reports.jsonl"
LOG_NAME = "processed_log.csv"
HEADERS_NAME = "_headers.json"
LOG_FIELDS = ["file", "size_bytes", "mtime", "processed_at", "n_fields", "status"]


def _scalar(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    return value


def flatten_json(obj: Any, parent_key: str = "", sep: str = ".") -> Dict[str, Any]:
    items: Dict[str, Any] = {}
    if isinstance(obj, dict):
        if not obj:
            items[parent_key] = ""
        for key, val in obj.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else str(key)
            items.update(flatten_json(val, new_key, sep=sep))
    elif isinstance(obj, (list, tuple)):
        items[parent_key] = _flatten_array(obj, sep=sep)
    else:
        items[parent_key] = _scalar(obj)
    return items


def _flatten_array(arr: Iterable[Any], sep: str = ".") -> str:
    parts: List[str] = []
    for el in arr:
        if isinstance(el, dict):
            flat = flatten_json(el, sep=sep)
            parts.append("; ".join(f"{k}={v}" for k, v in flat.items()))
        elif isinstance(el, (list, tuple)):
            parts.append(_flatten_array(el, sep=sep))
        else:
            s = _scalar(el)
            parts.append("" if s == "" else str(s))
    return ", ".join(parts)


def iter_json_files(input_dir: Path, state_dir: Path) -> Iterator[Path]:
    for p in sorted(input_dir.rglob("*.json")):
        try:
            p.relative_to(state_dir)
            continue
        except ValueError:
            yield p


def load_json_safe(path: Path) -> Tuple[Any, "str | None"]:
    try:
        with path.open("r", encoding="utf-8") as fh:
            return json.load(fh), None
    except json.JSONDecodeError as exc:
        return None, f"malformed JSON: {exc}"
    except UnicodeDecodeError:
        try:
            with path.open("r", encoding="utf-8", errors="replace") as fh:
                return json.load(fh), None
        except Exception as exc:
            return None, f"decode error: {exc}"
    except OSError as exc:
        return None, f"read error: {exc}"


def load_processed(log_path: Path) -> Set[str]:
    done: Set[str] = set()
    if not log_path.exists():
        return done
    with log_path.open("r", encoding="utf-8", newline="") as fh:
        for row in csv.DictReader(fh):
            if row.get("status", "").startswith("ok") or row.get("status") == "malformed":
                done.add(row["file"])
    return done


def load_headers(headers_path: Path) -> List[str]:
    if headers_path.exists():
        try:
            return json.loads(headers_path.read_text(encoding="utf-8"))
        except Exception:
            log.warning("could not read %s; rebuilding header union", headers_path.name)
    return []


def save_headers(headers_path: Path, headers: List[str]) -> None:
    headers_path.write_text(json.dumps(headers), encoding="utf-8")


def order_headers(keys: Set[str]) -> List[str]:
    ordered = sorted(keys)
    if "_source_file" in ordered:
        ordered.remove("_source_file")
        ordered = ["_source_file"] + ordered
    return ordered


def ingest_new_files(input_dir: Path, state_dir: Path):
    log_path = state_dir / LOG_NAME
    headers_path = state_dir / HEADERS_NAME
    master_path = state_dir / MASTER_JSONL
    already = load_processed(log_path)
    header_set: Set[str] = set(load_headers(headers_path))
    log.info("processed-log knows %d files; scanning for new ones...", len(already))
    n_new = n_failed = 0
    failed: List[str] = []
    now = datetime.now().isoformat(timespec="seconds")
    new_log_file = not log_path.exists()
    with master_path.open("a", encoding="utf-8") as master, \
            log_path.open("a", encoding="utf-8", newline="") as logfh:
        writer = csv.DictWriter(logfh, fieldnames=LOG_FIELDS)
        if new_log_file:
            writer.writeheader()
        for path in iter_json_files(input_dir, state_dir):
            if path.name in already:
                continue
            try:
                stat = path.stat()
                size, mtime = stat.st_size, datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds")
            except OSError:
                size, mtime = "", ""
            data, err = load_json_safe(path)
            if err is not None:
                n_failed += 1
                failed.append(f"{path.name}: {err}")
                writer.writerow({"file": path.name, "size_bytes": size, "mtime": mtime,
                                 "processed_at": now, "n_fields": 0, "status": "malformed"})
                log.warning("skipping %s (%s)", path.name, err)
                continue
            if not isinstance(data, dict):
                data = {"_root": data}
            flat = flatten_json(data)
            flat["_source_file"] = path.name
            header_set.update(flat.keys())
            master.write(json.dumps(flat, ensure_ascii=False) + "\n")
            writer.writerow({"file": path.name, "size_bytes": size, "mtime": mtime,
                             "processed_at": now, "n_fields": len(flat), "status": "ok"})
            already.add(path.name)
            n_new += 1
            if n_new % 2000 == 0:
                log.info("processed %d new files...", n_new)
    headers = order_headers(header_set)
    save_headers(headers_path, headers)
    total_rows = 0
    if master_path.exists():
        with master_path.open("r", encoding="utf-8") as fh:
            for _ in fh:
                total_rows += 1
    return n_new, n_failed, failed, headers, total_rows


def _none_if_blank(value: Any) -> Any:
    return None if (value is None or value == "") else str(value)


def rebuild_views(master_path: Path, headers: List[str], out_base: Path, formats: List[str]) -> Dict[str, str]:
    written: Dict[str, str] = {}
    if "jsonl" in formats:
        target = out_base.with_suffix(".jsonl")
        if target.resolve() != master_path.resolve():
            with master_path.open("r", encoding="utf-8") as src, target.open("w", encoding="utf-8") as dst:
                for line in src:
                    dst.write(line)
        written["jsonl"] = str(target)
    if "csv" in formats:
        target = out_base.with_suffix(".csv")
        with master_path.open("r", encoding="utf-8") as src, target.open("w", encoding="utf-8", newline="") as out:
            w = csv.writer(out)
            w.writerow(headers)
            for line in src:
                rec = json.loads(line)
                w.writerow([rec.get(c, "") for c in headers])
        written["csv"] = str(target)
    if "xlsx" in formats:
        target = out_base.with_suffix(".xlsx")
        if len(headers) > EXCEL_MAX_COLS:
            log.warning("skipping xlsx: %d fields exceed Excel limit", len(headers))
        else:
            wb = Workbook(write_only=True)
            ws = wb.create_sheet(title="patient_reports")
            ws.append(headers)
            n = 0
            with master_path.open("r", encoding="utf-8") as src:
                for line in src:
                    if n >= EXCEL_MAX_ROWS - 1:
                        break
                    rec = json.loads(line)
                    ws.append([rec.get(c, "") for c in headers])
                    n += 1
            wb.save(target)
            written["xlsx"] = str(target)
    if "parquet" in formats:
        target = out_base.with_suffix(".parquet")
        try:
            import pyarrow as pa
            import pyarrow.parquet as pq
        except ImportError:
            log.warning("skipping parquet: pyarrow not installed")
        else:
            writer = None
            buf: List[Dict[str, Any]] = []

            def flush(rows):
                nonlocal writer
                cols = {h: pa.array([_none_if_blank(r.get(h)) for r in rows], type=pa.string()) for h in headers}
                tbl = pa.table(cols)
                if writer is None:
                    writer = pq.ParquetWriter(target, tbl.schema, compression="snappy")
                writer.write_table(tbl)

            with master_path.open("r", encoding="utf-8") as src:
                for line in src:
                    buf.append(json.loads(line))
                    if len(buf) >= 5000:
                        flush(buf); buf.clear()
                if buf:
                    flush(buf)
            if writer is not None:
                writer.close()
                written["parquet"] = str(target)
    return written


def summarize(master_path: Path, headers: List[str], n_rows: int) -> pd.DataFrame:
    counts = {h: 0 for h in headers}
    with master_path.open("r", encoding="utf-8") as fh:
        for line in fh:
            for k, v in json.loads(line).items():
                if v not in ("", None):
                    counts[k] = counts.get(k, 0) + 1
    return (pd.DataFrame({"field": list(counts), "non_blank_count": list(counts.values())})
            .assign(fill_rate=lambda d: (d["non_blank_count"] / max(n_rows, 1)).round(4))
            .sort_values(["non_blank_count", "field"], ascending=[False, True])
            .reset_index(drop=True))


def parse_formats(raw: str) -> List[str]:
    if raw.strip().lower() == "all":
        return list(ALL_FORMATS)
    chosen = [f.strip().lower() for f in raw.split(",") if f.strip()]
    bad = [f for f in chosen if f not in ALL_FORMATS]
    if bad:
        raise argparse.ArgumentTypeError(f"unknown format(s): {', '.join(bad)}")
    return chosen


def main(argv: "List[str] | None" = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("input_dir", nargs="?", default=".")
    ap.add_argument("--state-dir", default=None)
    ap.add_argument("--out-name", default="patient_reports")
    ap.add_argument("--formats", type=parse_formats, default="all")
    ap.add_argument("--rebuild", action="store_true")
    args = ap.parse_args(argv)
    formats = args.formats if isinstance(args.formats, list) else parse_formats("all")
    input_dir = Path(args.input_dir).expanduser().resolve()
    if not input_dir.is_dir():
        log.error("input directory not found: %s", input_dir)
        return 2
    state_dir = Path(args.state_dir).expanduser().resolve() if args.state_dir else input_dir / "_pipeline"
    state_dir.mkdir(parents=True, exist_ok=True)
    master_path = state_dir / MASTER_JSONL
    if args.rebuild:
        log.info("--rebuild: clearing previous state")
        for f in (state_dir / LOG_NAME, state_dir / HEADERS_NAME, master_path):
            f.unlink(missing_ok=True)
    log.info("input : %s", input_dir)
    log.info("state : %s", state_dir)
    n_new, n_failed, failed, headers, total_rows = ingest_new_files(input_dir, state_dir)
    if total_rows == 0:
        log.error("no readable patient records found. Nothing to write.")
        return 1
    out_base = state_dir / args.out_name
    outputs_missing = any(not (out_base.with_suffix("." + f)).exists() for f in formats)
    if n_new > 0 or outputs_missing or args.rebuild:
        log.info("rebuilding output views: %s", ", ".join(formats))
        written = rebuild_views(master_path, headers, out_base, formats)
    else:
        log.info("no new files and all outputs present - nothing to rebuild")
        written = {f: str(out_base.with_suffix("." + f)) for f in formats if (out_base.with_suffix("." + f)).exists()}
    summary = summarize(master_path, headers, total_rows)
    summary.to_csv(state_dir / f"{args.out_name}_field_summary.csv", index=False)
    print("\n" + "=" * 66)
    print("  PATIENT REPORTS  ->  INCREMENTAL UNIFIED DATASET")
    print("=" * 66)
    print(f"  input directory : {input_dir}")
    print(f"  state directory : {state_dir}")
    print(f"  NEW files added : {n_new}")
    print(f"  files skipped   : {n_failed} malformed")
    print(f"  TOTAL records   : {total_rows}")
    print(f"  unique fields   : {len(headers)}")
    print("-" * 66)
    print("  Outputs refreshed:")
    for fmt in formats:
        pth = written.get(fmt)
        print(f"    {fmt:<8} {pth if pth else '(skipped)'}")
    print(f"    log      {state_dir / LOG_NAME}")
    print("-" * 66)
    print("  Top fields by fill rate:")
    for _, r in summary.head(20).iterrows():
        print(f"    {r['field']:<45} {int(r['non_blank_count']):>7}  ({r['fill_rate']:.1%})")
    if len(summary) > 20:
        print(f"    ... and {len(summary) - 20} more fields")
    if failed:
        print("-" * 66)
        print(f"  Malformed this run ({len(failed)}):")
        for f in failed[:20]:
            print(f"    - {f}")
    print("=" * 66 + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
