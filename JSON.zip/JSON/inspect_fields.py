#!/usr/bin/env python3
"""
inspect_fields.py

Cross-check tool: report how many fields each JSON file has and their names,
plus a global manifest of every field discovered — so you can confirm the
flattened dataset is not silently dropping data.

Produces:
  1. per_file_fields.csv   -> file, field_count, field_names (| separated)
  2. field_manifest.csv    -> field, files_present, fill_rate, example_value
  3. a console summary (totals, malformed files, rare/near-unique fields)

The flattening logic here is IDENTICAL to flatten_patient_reports.py, so the
field set it reports matches the columns that script would produce.

Usage
-----
    python inspect_fields.py [INPUT_DIR] [--outdir DIR] [--flat | --top-level]

    --flat        (default) count fully flattened dot-notation fields
    --top-level   count only top-level keys of each file (quick structural view)
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterator, List, Tuple

logging.basicConfig(level=logging.INFO, format="%(levelname)-7s %(message)s")
log = logging.getLogger("inspect")


# ---- flattening (kept in sync with flatten_patient_reports.py) ------------- #
def _scalar(v: Any) -> Any:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    return v


def _flatten_array(arr: Any, sep: str = ".") -> str:
    parts: List[str] = []
    for el in arr:
        if isinstance(el, dict):
            parts.append("; ".join(f"{k}={v}" for k, v in flatten(el, sep=sep).items()))
        elif isinstance(el, (list, tuple)):
            parts.append(_flatten_array(el, sep=sep))
        else:
            s = _scalar(el)
            parts.append("" if s == "" else str(s))
    return ", ".join(parts)


def flatten(obj: Any, parent: str = "", sep: str = ".") -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if isinstance(obj, dict):
        if not obj:
            out[parent] = ""
        for k, v in obj.items():
            nk = f"{parent}{sep}{k}" if parent else str(k)
            out.update(flatten(v, nk, sep=sep))
    elif isinstance(obj, (list, tuple)):
        out[parent] = _flatten_array(obj, sep=sep)
    else:
        out[parent] = _scalar(obj)
    return out


# ---- io -------------------------------------------------------------------- #
def iter_files(d: Path) -> Iterator[Path]:
    yield from sorted(d.rglob("*.json"))


def load_safe(p: Path) -> Tuple[Any, str | None]:
    try:
        with p.open("r", encoding="utf-8") as fh:
            return json.load(fh), None
    except json.JSONDecodeError as e:
        return None, f"malformed JSON: {e}"
    except Exception as e:  # noqa: BLE001
        return None, f"read error: {e}"


def fields_of(data: Any, top_level_only: bool) -> Dict[str, Any]:
    if not isinstance(data, dict):
        data = {"_root": data}
    if top_level_only:
        # value shown as-is (stringified) just for the example column
        return {k: _scalar(v) if not isinstance(v, (dict, list)) else "<nested>"
                for k, v in data.items()}
    return flatten(data)


# ---- main ------------------------------------------------------------------ #
def main(argv: List[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("input_dir", nargs="?", default=".")
    ap.add_argument("--outdir", default=".", help="where to write the two CSVs")
    mode = ap.add_mutually_exclusive_group()
    mode.add_argument("--flat", action="store_true",
                      help="count fully flattened fields (default)")
    mode.add_argument("--top-level", action="store_true",
                      help="count only top-level keys")
    args = ap.parse_args(argv)

    top_only = args.top_level  # flat is the default when neither is passed
    input_dir = Path(args.input_dir).expanduser().resolve()
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    if not input_dir.is_dir():
        log.error("input directory not found: %s", input_dir)
        return 2

    per_file_path = outdir / "per_file_fields.csv"
    manifest_path = outdir / "field_manifest.csv"

    global_counter: Counter[str] = Counter()   # field -> #files containing it
    example: Dict[str, str] = {}               # field -> first non-blank value seen
    n_ok = n_bad = 0
    bad: List[str] = []
    field_counts_per_file: List[int] = []

    import csv
    with per_file_path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["file", "field_count", "field_names"])
        for p in iter_files(input_dir):
            data, err = load_safe(p)
            if err:
                n_bad += 1
                bad.append(f"{p.name}: {err}")
                w.writerow([p.name, "ERROR", err])
                continue
            flat = fields_of(data, top_only)
            names = sorted(flat.keys())
            w.writerow([p.name, len(names), " | ".join(names)])
            field_counts_per_file.append(len(names))
            n_ok += 1
            for k, v in flat.items():
                global_counter[k] += 1
                if k not in example and v not in ("", None):
                    example[k] = str(v)[:60]

    # global manifest
    with manifest_path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["field", "files_present", "fill_rate", "example_value"])
        for field, cnt in sorted(global_counter.items(),
                                 key=lambda x: (-x[1], x[0])):
            rate = round(cnt / max(n_ok, 1), 4)
            w.writerow([field, cnt, rate, example.get(field, "")])

    # ---- console report ---------------------------------------------------- #
    total_unique = len(global_counter)
    universal = sum(1 for c in global_counter.values() if c == n_ok)
    rare = sorted(f for f, c in global_counter.items() if c == 1)

    print("\n" + "=" * 62)
    print("  FIELD INSPECTION" + ("  (top-level keys)" if top_only else "  (flattened)"))
    print("=" * 62)
    print(f"  directory        : {input_dir}")
    print(f"  files OK         : {n_ok}")
    print(f"  files malformed  : {n_bad}")
    print(f"  UNIQUE fields    : {total_unique}")
    if field_counts_per_file:
        print(f"  fields / file    : min {min(field_counts_per_file)}  "
              f"max {max(field_counts_per_file)}  "
              f"avg {sum(field_counts_per_file)/len(field_counts_per_file):.1f}")
    print(f"  present in ALL   : {universal}")
    print(f"  present in ONE   : {len(rare)}  (possible typos / stragglers)")
    print("-" * 62)
    print(f"  wrote  {per_file_path.name}   (one row per file)")
    print(f"  wrote  {manifest_path.name}   (one row per field)")
    if rare:
        print("-" * 62)
        print("  Fields that appear in only ONE file (double-check these):")
        for f in rare[:30]:
            print(f"    - {f}")
        if len(rare) > 30:
            print(f"    ... and {len(rare) - 30} more")
    if bad:
        print("-" * 62)
        print(f"  Malformed files ({n_bad}):")
        for b in bad[:20]:
            print(f"    - {b}")
        if len(bad) > 20:
            print(f"    ... and {len(bad) - 20} more")
    print("=" * 62 + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
